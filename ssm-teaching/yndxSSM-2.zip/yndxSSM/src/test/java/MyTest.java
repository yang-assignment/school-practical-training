
//这里是开始使用JUnit单元测试工具开始测试

import beans.Dog;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import service.IUserService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springContext.xml"})
public class MyTest {

    @Autowired
    public Dog dog;

    @Autowired
    IUserService userService;


    @Test
    public void test0() {
        System.out.println(dog);
    }

    //练习 在bean.xml创建service对象
    //练习 在这里使用注解获取service对象

    @Test
    public void testService() {
        System.out.println(userService.findAll());
    }

}
