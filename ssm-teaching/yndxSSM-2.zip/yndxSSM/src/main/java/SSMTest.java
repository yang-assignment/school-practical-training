import beans.Dog;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SSMTest {


    public static void main(String[] args) {
        //模拟前端操作业务层
        //客户端调用 业务层接口  --- 调用业务层实现类

        // 创建容器，让容器创建对象。
        ApplicationContext context = new ClassPathXmlApplicationContext("springContext.xml");
        Dog dog = (Dog) context.getBean("dog");

        System.out.println(dog);

    }


}

