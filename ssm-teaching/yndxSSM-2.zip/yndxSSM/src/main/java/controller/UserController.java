package controller;

import beans.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller//用于创建controller对象
public class UserController {

//    @RequestMapping(value = "/login" ,method = RequestMethod.GET,params = {"username"})
//    @ResponseBody
//    public String login(){
//        System.out.println("我已经进入到login方法了，测试成功");
//        return "first study springmvc";
//    }

//    @RequestMapping(value = "/login")
//    @ResponseBody
//    public String login(String username,String password) {
//        System.out.println("我已经进入到login方法了，测试成功");
//        System.out.println("username:"+username+" password: "+password);
//
//        return "first study springmvc";
//    }


//    @RequestMapping(value = "/login")
//    @ResponseBody
//    public String login(@RequestParam("username") String name, @RequestParam("password") String pwd) {
//        System.out.println("我已经进入到login方法了，测试成功");
//        System.out.println("username:"+name+" password: "+pwd);
//
//        return "first study springmvc";
//    }

//    @RequestMapping(value = "/login")
//    public String login(User user) {
//        System.out.println("我已经进入到login方法了，测试成功");
//        System.out.println("username:"+user.getUsername()+" password: "+user.getPassword());
//        System.out.println(user);
//        System.out.println("这是模拟已经调用了业务层，将业务层的数据返回给main.jsp页面");
//        return "main";
//    }


    @RequestMapping( "/login")
    public String login(User user) {
        System.out.println("我已经进入到login方法了，测试成功");
        System.out.println("username:"+user.getUsername()+" password: "+user.getPassword());
        System.out.println(user);
        return "forward:/check";
    }

    @RequestMapping( "/check")
    public String check(User user) {
        System.out.println(user);
       if (user.getUsername().equals("xsz")&&user.getPassword().equals("123456")){
           return "success";
       }else {
           return "error";
       }

    }


}
