package dao.impl;

import beans.User;
import dao.IUserDao;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import service.IUserService;
import utils.DatabaseUtil;
import utils.JDBCUtils;

import java.io.InputStream;
import java.sql.*;
import java.util.List;

public class UserDaoImpl implements IUserDao {

    //使用操作数据库的一个模板  JDBCTemplate  需要 和数据库相关的东西
    // driver url username password
    // 创建JdbcTemplate这个对象需要一个参数，是 DataSource
    private JdbcTemplate template =new JdbcTemplate(JDBCUtils.getDataSource());

    @Override
    public List<User> findAll() {

        String sql = "select * from user";
        List<User> users = template.query(sql,new BeanPropertyRowMapper<User>(User.class));
        return users;
    }


    @Override
    public User findUserByNameAndPwd(User user) {

        return  null;
    }


    public int insert(User user)  {

        String sql = "insert into user values(?,?)";

        int result = template.update(sql,user);
        System.out.println(result);
        return  result;
    }


}
