package dao.impl;

import beans.User;
import dao.IUserDao;
import utils.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class UserDaoImplbakbak implements IUserDao {

    @Override
    public User findUserByNameAndPwd(User user) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        String driverClassName = DatabaseUtil.driver;
        String url = DatabaseUtil.url;
        String username = DatabaseUtil.user;
        String password = DatabaseUtil.password;

        try {

            // 创建数据库连接
            con = DatabaseUtil.getConnection();

            // 编写sql语句
            String sql = "select * from user where username = ? and password = ?";

            // 创建操作数据库的对象
            pstmt = con.prepareStatement(sql);
            pstmt.setNString(1, user.getUsername());
            pstmt.setNString(2, user.getPassword());

            // 执行返回结果
            rs = pstmt.executeQuery();

            User findUser = null;
            while (rs.next()) {
                findUser = new User();
                findUser.setUsername(rs.getString("username"));
                findUser.setPassword(rs.getString("password"));
            }
            return findUser;

        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
           DatabaseUtil.closeAll(con,pstmt,rs);
        }

    }


    public int insert(User user){
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        String driverClassName = DatabaseUtil.driver;
        String url = DatabaseUtil.url;
        String username = DatabaseUtil.user;
        String password = DatabaseUtil.password;


        try {
            // 创建数据库连接
            con = DatabaseUtil.getConnection();
            // 编写sql语句
            String sql = "INSERT INTO USER VALUES(?,?)"; //设置的预编译语句格式

            // 创建操作数据库的对象
            pstmt = con.prepareStatement(sql);
            pstmt.setNString(1, user.getUsername());
            pstmt.setNString(2, user.getPassword());

            int result = pstmt.executeUpdate();

            return result;

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseUtil.closeAll(con,pstmt,rs);
        }
        return 0;

    }

    @Override
    public List<User> findAll() {
        return null;
    }
}
