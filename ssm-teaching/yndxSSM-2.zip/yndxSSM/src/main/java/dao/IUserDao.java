package dao;

import beans.User;

import java.sql.SQLException;
import java.util.List;

public interface IUserDao {
    public User findUserByNameAndPwd(User user);
    public int insert(User user) ;
    public List<User> findAll() ;
}
