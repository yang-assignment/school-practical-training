package service.impl;

import beans.User;
import dao.IUserDao;
import dao.impl.UserDaoImpl;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import service.IUserService;

import java.sql.SQLException;
import java.util.List;

@Service("userService")
public class UserServiceImpl implements IUserService {
    private IUserDao dao = new UserDaoImpl();

    @Override
    public User findUserByNameAndPwd(User user) {

        //调用持久层接口
        return  dao.findUserByNameAndPwd(user);
    }

    @Override
    public int insert(User user) {
        return dao.insert(user);
    }

    @Override
    public List<User> findAll() {
        return dao.findAll();
    }
}
