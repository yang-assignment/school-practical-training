import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class BeanFactory {

    public static Map<String, Object> beans;

    static {
        //开始生产  使用Properties对象生产
        Properties pros = new Properties();

        try {
            //到库房拿材料
            InputStream is = BeanFactory.class.getClassLoader().getResourceAsStream("bean.properties");

            pros.load(is);

            Enumeration keys = pros.keys();

            //容器
            beans = new HashMap();

            while (keys.hasMoreElements()) {
                String key = keys.nextElement().toString();
                String className = pros.getProperty(key);
                Object value = Class.forName(className).newInstance();
                beans.put(key, value);
            }

        } catch (IOException | ClassNotFoundException ioException) {
            ioException.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        }
    }

    public static Object getBean(String key)
    {
        return beans.get(key);
    }
    
}
