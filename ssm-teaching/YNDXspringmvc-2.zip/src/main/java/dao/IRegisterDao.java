package dao;

import beans.Register;

import java.sql.SQLException;
import java.util.List;

public interface IRegisterDao {
    public int insert(Register register);
    public List<Register> findAll();
}
