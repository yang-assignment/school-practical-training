package beans;

public class LoginUser {
}
