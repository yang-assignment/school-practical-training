package beans;


import java.io.Serializable;

public class Register implements Serializable {
   private String registerId;
   private String registerName;
   private String registerAge;
   private String registerMajor;
   private String registerSex;
   private String registerAddress;
   private String registerEmail;

    public Register() {
    }

    public Register(String registerId, String registerName, String registerAge, String registerMajor, String registerSex, String registerAddress, String registerEmail) {
        this.registerId = registerId;
        this.registerName = registerName;
        this.registerAge = registerAge;
        this.registerMajor = registerMajor;
        this.registerSex = registerSex;
        this.registerAddress = registerAddress;
        this.registerEmail = registerEmail;
    }

    @Override
    public String toString() {
        return "Register{" +
                "registerId='" + registerId + '\'' +
                ", registerName='" + registerName + '\'' +
                ", registerAge='" + registerAge + '\'' +
                ", registerMajor='" + registerMajor + '\'' +
                ", registerSex='" + registerSex + '\'' +
                ", registerAddress='" + registerAddress + '\'' +
                ", registerEmail='" + registerEmail + '\'' +
                '}';
    }

    public String getRegisterId() {
        return registerId;
    }

    public void setRegisterId(String registerId) {
        this.registerId = registerId;
    }

    public String getRegisterName() {
        return registerName;
    }

    public void setRegisterName(String registerName) {
        this.registerName = registerName;
    }

    public String getRegisterAge() {
        return registerAge;
    }

    public void setRegisterAge(String registerAge) {
        this.registerAge = registerAge;
    }

    public String getRegisterMajor() {
        return registerMajor;
    }

    public void setRegisterMajor(String registerMajor) {
        this.registerMajor = registerMajor;
    }

    public String getRegisterSex() {
        return registerSex;
    }

    public void setRegisterSex(String registerSex) {
        this.registerSex = registerSex;
    }

    public String getRegisterAddress() {
        return registerAddress;
    }

    public void setRegisterAddress(String registerAddress) {
        this.registerAddress = registerAddress;
    }

    public String getRegisterEmail() {
        return registerEmail;
    }

    public void setRegisterEmail(String registerEmail) {
        this.registerEmail = registerEmail;
    }
}
