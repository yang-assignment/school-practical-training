package service;

import beans.Register;

import java.util.List;

public interface IRegisterService {
    public int insert(Register register) ;
    public List<Register> findAll();
}
