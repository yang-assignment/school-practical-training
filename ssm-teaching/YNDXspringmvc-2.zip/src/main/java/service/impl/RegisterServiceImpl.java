package service.impl;

import beans.Register;
import beans.User;
import dao.IRegisterDao;
import dao.IUserDao;
import dao.impl.UserDaoImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import service.IRegisterService;
import service.IUserService;

import java.sql.SQLException;
import java.util.List;

@Service
public class RegisterServiceImpl implements IRegisterService {

   @Autowired
   private IRegisterDao dao;


    @Override
    public int insert(Register register)  {
         int resutl =dao.insert(register);
        return resutl;
    }

    @Override
    public List<Register> findAll() {
        return null;
    }
}
