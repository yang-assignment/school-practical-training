package controller;

import beans.Register;
import beans.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import service.IRegisterService;
import service.IUserService;

@Controller
public class UserController {

    @Autowired
    IRegisterService service;


    @Autowired
    IUserService userService;


    @RequestMapping("/regist")
    public String regist(Register register) {
        System.out.println(register);
        //现在需要将register数据保存到数据数据库
        int result = service.insert(register);
        if (result == 1) {
            return "login";
        } else {
            return "error";
        }
    }


    @RequestMapping("/login")
    public String login(User user) {
        System.out.println(user);
      //到数据库查询用户是否存在
       User findUser = userService.findUserByNameAndPwd(user);

       if (findUser==null){
           return "error";
       }else {
           return "main";
       }
    }


}
