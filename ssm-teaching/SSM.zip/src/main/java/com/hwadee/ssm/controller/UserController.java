package com.hwadee.ssm.controller;

import com.hwadee.ssm.beans.Register;
import com.hwadee.ssm.beans.User;
import com.hwadee.ssm.dao.IUserDao;
import com.hwadee.ssm.service.IRegisterService;
import com.hwadee.ssm.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class UserController {


    @Autowired
    IRegisterService service;

    @RequestMapping("/")
    public String registPage() {
        System.out.println(123456789);
        return "regist";
    }

    @RequestMapping(value = "/regist")
    public String regist(Register register) {
        System.out.println(3429);
        int result = service.insert(register);
        if (result != 0) {
            return "login";
        } else {
            return "error";
        }
    }


}
