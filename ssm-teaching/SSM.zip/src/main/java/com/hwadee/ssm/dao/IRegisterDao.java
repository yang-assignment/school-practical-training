package com.hwadee.ssm.dao;

import com.hwadee.ssm.beans.Register;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IRegisterDao {
    //插入数据方法
    public int insert(Register register);

    //查找方法
    public List<Register> findAll();
}
