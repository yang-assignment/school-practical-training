package com.hwadee.ssm.dao;

import com.hwadee.ssm.beans.User;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IUserDao {
    //插入数据方法
    public int insert(User user);

    //查找方法
    public List<User> findAll();

    // 根据用户明后密码查找
    public User findUserByNameAndPwd();


}
