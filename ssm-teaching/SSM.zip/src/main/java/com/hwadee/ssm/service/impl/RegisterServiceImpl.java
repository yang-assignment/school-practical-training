package com.hwadee.ssm.service.impl;

import com.hwadee.ssm.beans.Register;
import com.hwadee.ssm.beans.User;
import com.hwadee.ssm.dao.IRegisterDao;
import com.hwadee.ssm.dao.IUserDao;
import com.hwadee.ssm.service.IRegisterService;
import com.hwadee.ssm.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RegisterServiceImpl implements IRegisterService {
   @Autowired
    IRegisterDao dao;

    @Override
    public int insert(Register register) {
        return dao.insert(register);
    }

    @Override
    public List<Register> findAll() {
        return dao.findAll();
    }
}
