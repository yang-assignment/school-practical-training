package com.hwadee.ssm.service.impl;

import com.hwadee.ssm.beans.User;
import com.hwadee.ssm.dao.IUserDao;
import com.hwadee.ssm.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements IUserService {

    @Autowired
    IUserDao dao;

    @Override
    public int insert(User user) {
        return dao.insert(user);
    }

    @Override
    public List<User> findAll() {
        return dao.findAll();
    }

    @Override
    public User findUserByNameAndPwd() {
        return dao.findUserByNameAndPwd();
    }
}
