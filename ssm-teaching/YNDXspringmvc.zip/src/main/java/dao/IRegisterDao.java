package dao;

import beans.Register;

import java.sql.SQLException;

public interface IRegisterDao {
    public int insert(Register register);
}
