package dao.impl;

import beans.User;
import dao.IUserDao;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import utils.JDBCUtils;

import java.sql.SQLException;
import java.util.List;

@Repository
public class UserDaoImpl implements IUserDao {

    //使用操作数据库的一个模板  JDBCTemplate  需要 和数据库相关的东西
    // driver url username password
    // 创建JdbcTemplate这个对象需要一个参数，是 DataSource
    private JdbcTemplate template =new JdbcTemplate(JDBCUtils.getDataSource());

    @Override
    public List<User> findAll() {

        String sql = "select * from user";
        List<User> users = template.query(sql,new BeanPropertyRowMapper<User>(User.class));
        return users;
    }


    @Override
    public User findUserByNameAndPwd(User user) {

//       模拟查询数据库
        System.out.println("模拟查询数据库");
        return  user;
    }


    public int insert(User user) throws SQLException {
        return  0;
    }


}
