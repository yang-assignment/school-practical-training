package dao.impl;

import beans.Register;
import beans.User;
import dao.IRegisterDao;
import dao.IUserDao;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import utils.JDBCUtils;

import java.sql.SQLException;
import java.util.List;

@Repository
public class RegisterDaoImpl implements IRegisterDao {

    //使用操作数据库的一个模板  JDBCTemplate  需要 和数据库相关的东西
    // driver url username password
    // 创建JdbcTemplate这个对象需要一个参数，是 DataSource
    private JdbcTemplate template =new JdbcTemplate(JDBCUtils.getDataSource());


    @Override
    public int insert(Register register)  {
        System.out.println("模拟保存数据");
        return 1;
    }
}
