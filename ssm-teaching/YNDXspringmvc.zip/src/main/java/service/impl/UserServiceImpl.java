package service.impl;

import beans.User;
import dao.IUserDao;
import dao.impl.UserDaoImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import service.IUserService;

import java.sql.SQLException;
import java.util.List;

@Service("userService")
public class UserServiceImpl implements IUserService {

    @Autowired
    private IUserDao dao ;


    @Override
    public User findUserByNameAndPwd(User user) {

        //调用持久层接口
        return  dao.findUserByNameAndPwd(user);
    }

    @Override
    public int insert(User user) throws SQLException {
        return dao.insert(user);
    }

    @Override
    public List<User> findAll() {
        return dao.findAll();
    }
}
