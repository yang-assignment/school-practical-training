package service;

import beans.Register;
import java.sql.SQLException;

public interface IRegisterService {
    public int insert(Register register) ;
}
