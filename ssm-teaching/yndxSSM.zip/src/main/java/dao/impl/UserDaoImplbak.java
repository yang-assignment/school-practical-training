package dao.impl;

import beans.User;
import dao.IUserDao;

import java.sql.*;
import java.util.List;

public class UserDaoImplbak implements IUserDao {

    @Override
    public User findUserByNameAndPwd(User user) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        /*
          1、需要驱动
             "com.mysql.jdbc.Driver"; 适用与8.0以下
             "com.mysql.cj.jdbc.Driver"; 适用与8.上
          2、需要url
              "jdbc:mysql://localhost:3306/yndx";
          3、用户名 root
          4、密码   root
         */

        String driverClassName = "com.mysql.cj.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/yndx?serverTimezone=UTC&useSSL=false";
        String username = "root";
        String password = "root";

        try {
            // 驱动数据库
            Class.forName(driverClassName);

            // 创建数据库连接
            con = DriverManager.getConnection(url, username, password);

            // 编写sql语句
            String sql = "select * from user where username = ? and password = ?";

            // 创建操作数据库的对象
            pstmt = con.prepareStatement(sql);
            pstmt.setNString(1, user.getUsername());
            pstmt.setNString(2, user.getPassword());

            // 执行返回结果
            rs = pstmt.executeQuery();

            User findUser = null;
            while (rs.next()) {
                findUser = new User();
                findUser.setUsername(rs.getString("username"));
                findUser.setPassword(rs.getString("password"));
            }
            return findUser;

        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            //关闭资源,倒关
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (con != null) con.close();  //必须要关
            } catch (Exception e) {
            }
        }

    }


    public int insert(User user) throws SQLException {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        String driverClassName = "com.mysql.cj.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/yndx?serverTimezone=UTC&useSSL=false";
        String username = "root";
        String password = "root";


        try {      //获取连接
            // 驱动数据库
            Class.forName(driverClassName);

            // 创建数据库连接
            con = DriverManager.getConnection(url, username, password);

            // 编写sql语句
            String sql = "INSERT INTO USER VALUES(?,?)"; //设置的预编译语句格式

            // 创建操作数据库的对象
            pstmt = con.prepareStatement(sql);
            pstmt.setNString(1, user.getUsername());
            pstmt.setNString(2, user.getPassword());

            int result = pstmt.executeUpdate();

            return result;

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            //关闭资源,倒关
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (con != null) con.close();  //必须要关
            } catch (Exception e) {
            }
        }
        return 0;

    }

    @Override
    public List<User> findAll() {
        return null;
    }
}
