import beans.User;
import service.IUserService;
import service.impl.UserServiceImpl;

import java.sql.*;

public class SSMTest {
    public static void main(String[] args) {
        //模拟前端操作业务层
        //客户端调用 业务层接口  --- 调用业务层实现类
        IUserService service = new UserServiceImpl();
        User user = new User("admin", "123456");
        User findUser = service.findUserByNameAndPwd(user);
        System.out.println(findUser);


        System.out.println(service.findAll());
    }



}

